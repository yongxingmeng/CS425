#include <stdio.h>


int main(){

	fprintf(stderr, "Hello World!\n");
	return 0;
}
